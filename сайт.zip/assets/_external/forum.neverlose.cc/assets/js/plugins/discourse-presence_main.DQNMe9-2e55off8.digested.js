const{default:e}=window.moduleBroker.lookup("@glimmer/component",!1,["default"]),{tracked:t,cached:s}=window.moduleBroker.lookup("@glimmer/tracking",!1,["tracked","cached"]),{default:n,service:r}=window.moduleBroker.lookup("@ember/service",!1,["default","service"]),{default:i}=window.moduleBroker.lookup("discourse/helpers/helper-fn",!1,["default"]),{default:o}=window.moduleBroker.lookup("discourse/models/composer",!1,["default"]),{default:l}=window.moduleBroker.lookup("discourse/ui-kit/d-user-link",!1,["default"]),{default:a}=window.moduleBroker.lookup("discourse/ui-kit/helpers/d-avatar",!1,["default"]),{i18n:c}=window.moduleBroker.lookup("discourse-i18n",!1,["i18n"]),{gt:u,and:p,concat:d}=window.moduleBroker.lookup("@ember/helper",!1,["gt","and","concat"]),{setComponentTemplate:h}=window.moduleBroker.lookup("@ember/component",!1,["setComponentTemplate"]),{createTemplateFactory:m}=window.moduleBroker.lookup("@ember/template-factory",!1,["createTemplateFactory"]),{registerModuleForModifyClass:g}=window.moduleBroker.lookup("discourse/lib/deferred-class-modifications",!1,["registerModuleForModifyClass"]),{default:y}=window.moduleBroker.lookup("@ember/component/template-only",!1,["default"]),{trustHTML:w}=window.moduleBroker.lookup("@ember/template",!1,["trustHTML"]),{translateSize:_}=window.moduleBroker.lookup("discourse/lib/avatar-utils",!1,["translateSize"]),{_INTERNAL_SOURCE_KEY:f}=window.moduleBroker.lookup("discourse/lib/api",!1,["_INTERNAL_SOURCE_KEY"]),{withPluginApi:k}=window.moduleBroker.lookup("discourse/lib/plugin-api",!1,["withPluginApi"]),{debounce:b,cancel:C}=window.moduleBroker.lookup("@ember/runloop",!1,["debounce","cancel"]),{isTesting:v}=window.moduleBroker.lookup("discourse/lib/environment",!1,["isTesting"])
class T extends e{static{dt7948.g(this.prototype,"capabilities",[r])}#e=void dt7948.i(this,"capabilities")
static{dt7948.g(this.prototype,"presence",[r])}#t=void dt7948.i(this,"presence")
static{dt7948.g(this.prototype,"composerPresenceManager",[r])}#s=void dt7948.i(this,"composerPresenceManager")
static{dt7948.g(this.prototype,"currentUser",[r])}#n=void dt7948.i(this,"currentUser")
static{dt7948.g(this.prototype,"siteSettings",[r])}#r=void dt7948.i(this,"siteSettings")
static{dt7948.g(this.prototype,"replyChannel",[t])}#i=void dt7948.i(this,"replyChannel")
static{dt7948.g(this.prototype,"whisperChannel",[t])}#o=void dt7948.i(this,"whisperChannel")
static{dt7948.g(this.prototype,"editChannel",[t])}#l=void dt7948.i(this,"editChannel")
static{dt7948.g(this.prototype,"translateChannel",[t])}#a=void dt7948.i(this,"translateChannel")
setupReplyChannel=i((e,t)=>{const{topic:s}=this.args.model
if(!s||!this.isReply)return
const n=`/discourse-presence/reply/${s.id}`,r=this.presence.getChannel(n)
this.replyChannel=r,r.subscribe(),t.cleanup(()=>r.unsubscribe())})
setupWhisperChannel=i((e,t)=>{const{topic:s}=this.args.model,{whisperer:n}=this.currentUser
if(!s||!this.isReply||!n)return
const r=`/discourse-presence/whisper/${s.id}`,i=this.presence.getChannel(r)
this.whisperChannel=i,i.subscribe(),t.cleanup(()=>i.unsubscribe())})
setupEditChannel=i((e,t)=>{const{post:s}=this.args.model
if(!s||!this.isEdit)return
const n=`/discourse-presence/edit/${s.id}`,r=this.presence.getChannel(n)
this.editChannel=r,r.subscribe(),t.cleanup(()=>r.unsubscribe())})
setupTranslateChannel=i((e,t)=>{const{post:s}=this.args.model
if(!s||!this.isTranslate)return
const n=`/discourse-presence/translate/${s.id}`,r=this.presence.getChannel(n)
this.translateChannel=r,r.subscribe(),t.cleanup(()=>r.unsubscribe())})
notifyState=i((e,t)=>{const{topic:s,post:n,replyDirty:r}=this.args.model,i=this.isEdit||this.isTranslate?n:s
if(i){const e=`/discourse-presence/${this.state}/${i.id}`
this.composerPresenceManager.notifyState(e,r)}t.cleanup(()=>this.composerPresenceManager.leave())})
get isReply(){return"reply"===this.state||"whisper"===this.state}get isEdit(){return"edit"===this.state}get isTranslate(){return"translate"===this.state}get state(){const{editingPost:e,whisper:t,replyingToTopic:s,action:n}=this.args.model
return n===o.ADD_TRANSLATION?"translate":e?"edit":t?"whisper":s?"reply":void 0}static{dt7948.n(this.prototype,"state",[s])}get users(){let e
if(this.isEdit)e=this.editChannel?.users||[]
else if(this.isTranslate)e=this.translateChannel?.users||[]
else{e=[...this.replyChannel?.users||[],...this.whisperChannel?.users||[]]}return e.filter(e=>e.id!==this.currentUser.id).slice(0,this.siteSettings.presence_max_users_shown)}static{dt7948.n(this.prototype,"users",[s])}static{h(m({id:null,block:'[[[41,[30,0,["currentUser"]],[[[1,"  "],[1,[30,0,["setupReplyChannel"]]],[1,"\\n  "],[1,[30,0,["setupWhisperChannel"]]],[1,"\\n  "],[1,[30,0,["setupEditChannel"]]],[1,"\\n  "],[1,[30,0,["setupTranslateChannel"]]],[1,"\\n  "],[1,[30,0,["notifyState"]]],[1,"\\n\\n"],[41,[28,[32,0],[[30,0,["capabilities","viewport","sm"]],[28,[32,1],[[30,0,["users","length"]],0],null]],null],[[[1,"    "],[10,0],[14,0,"presence-users"],[12],[1,"\\n      "],[10,0],[14,0,"presence-avatars"],[12],[1,"\\n"],[42,[28,[31,2],[[28,[31,2],[[30,0,["users"]]],null]],null],null,[[[1,"          "],[8,[32,2],null,[["@user"],[[30,1]]],[["default"],[[[[1,"\\n            "],[1,[28,[32,3],[[30,1]],[["imageSize"],["small"]]]],[1,"\\n          "]],[]]]]],[1,"\\n"]],[1]],null],[1,"      "],[13],[1,"\\n\\n      "],[10,1],[14,0,"presence-text"],[12],[1,"\\n        "],[10,1],[14,0,"description"],[12],[41,[30,0,["isReply"]],[[[1,[28,[32,4],["presence.replying"],[["count"],[[30,0,["users","length"]]]]]]],[]],[[[41,[30,0,["isTranslate"]],[[[1,[28,[32,4],["presence.translating"],[["count"],[[30,0,["users","length"]]]]]]],[]],[[[1,[28,[32,4],["presence.editing"],[["count"],[[30,0,["users","length"]]]]]]],[]]]],[]]],[13],[1,"\\n        "],[10,1],[14,0,"wave"],[12],[1,"\\n          "],[10,1],[14,0,"dot"],[12],[1,"."],[13],[1,"\\n          "],[10,1],[14,0,"dot"],[12],[1,"."],[13],[1,"\\n          "],[10,1],[14,0,"dot"],[12],[1,"."],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n"]],[]],null]],[]],null]],["user"],["if","each","-track-array"]]',moduleName:"(unknown template module)",scope:()=>({__keyword__and:p,__keyword__gt:u,DUserLink:l,dAvatar:a,i18n:c}),isStrictMode:!0}),this)}}g("composer-presence-display",T)
var S=Object.freeze({__proto__:null,default:T})
class U extends e{static{dt7948.g(this.prototype,"presence",[r])}#t=void dt7948.i(this,"presence")
static{dt7948.g(this.prototype,"currentUser",[r])}#n=void dt7948.i(this,"currentUser")
static{dt7948.g(this.prototype,"replyChannel",[t])}#i=void dt7948.i(this,"replyChannel")
static{dt7948.g(this.prototype,"whisperChannel",[t])}#o=void dt7948.i(this,"whisperChannel")
setupReplyChannel=i((e,t)=>{const{topic:s}=this.args
if(!s)return
const n=`/discourse-presence/reply/${s.id}`,r=this.presence.getChannel(n)
this.replyChannel=r,r.subscribe(),t.cleanup(()=>r.unsubscribe())})
setupWhisperChannel=i((e,t)=>{const{topic:s}=this.args,{whisperer:n}=this.currentUser
if(!s||!n)return
const r=`/discourse-presence/whisper/${s.id}`,i=this.presence.getChannel(r)
this.whisperChannel=i,i.subscribe(),t.cleanup(()=>i.unsubscribe())})
get users(){return[...this.replyChannel?.users||[],...this.whisperChannel?.users||[]].filter(e=>e.id!==this.currentUser.id)}static{dt7948.n(this.prototype,"users",[s])}static{h(m({id:null,block:'[[[41,[30,0,["currentUser"]],[[[1,"  "],[1,[30,0,["setupReplyChannel"]]],[1,"\\n  "],[1,[30,0,["setupWhisperChannel"]]],[1,"\\n\\n"],[41,[28,[32,0],[[30,0,["users","length"]],0],null],[[[1,"    "],[10,0],[14,0,"presence-users"],[12],[1,"\\n      "],[10,0],[14,0,"presence-avatars"],[12],[1,"\\n"],[42,[28,[31,2],[[28,[31,2],[[30,0,["users"]]],null]],null],null,[[[1,"          "],[8,[32,1],null,[["@user"],[[30,1]]],[["default"],[[[[1,"\\n            "],[1,[28,[32,2],[[30,1]],[["imageSize"],[[30,2]]]]],[1,"\\n          "]],[]]]]],[1,"\\n"]],[1]],null],[1,"      "],[13],[1,"\\n\\n      "],[10,1],[14,0,"presence-text"],[12],[1,"\\n        "],[10,1],[14,0,"description"],[12],[1,"\\n          "],[1,[28,[32,3],["presence.replying_to_topic"],[["count"],[[30,0,["users","length"]]]]]],[1,"\\n        "],[13],[1,"\\n        "],[10,1],[14,0,"wave"],[12],[1,"\\n          "],[10,1],[14,0,"dot"],[12],[1,"."],[13],[1,"\\n          "],[10,1],[14,0,"dot"],[12],[1,"."],[13],[1,"\\n          "],[10,1],[14,0,"dot"],[12],[1,"."],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n"]],[]],null]],[]],null]],["user","@avatarSize"],["if","each","-track-array"]]',moduleName:"(unknown template module)",scope:()=>({__keyword__gt:u,DUserLink:l,dAvatar:a,i18n:c}),isStrictMode:!0}),this)}}g("topic-presence-display",U)
var B=Object.freeze({__proto__:null,default:U})
const M=h(m({id:null,block:'[[[10,0],[14,0,"before-composer-controls-outlet presence"],[12],[1,"\\n  "],[8,[32,0],null,[["@model"],[[30,1,["model"]]]],null],[1,"\\n"],[13]],["@outletArgs"],[]]',moduleName:"(unknown template module)",scope:()=>({ComposerPresenceDisplay:T}),isStrictMode:!0}),y())
var z=Object.freeze({__proto__:null,default:M})
const A="small"
class R extends e{get avatarDimensions(){return _(A)}static{h(m({id:null,block:'[[[10,0],[14,0,"topic-above-footer-buttons-outlet presence"],[15,5,[28,[32,0],[[28,[32,1],["--avatar-min-height: ",[30,0,["avatarDimensions"]],"px"],null]],null]],[12],[1,"\\n  "],[8,[32,2],null,[["@avatarSize","@topic"],[[32,3],[30,1,["model"]]]],null],[1,"\\n"],[13]],["@outletArgs"],[]]',moduleName:"(unknown template module)",scope:()=>({trustHTML:w,concat:d,TopicPresenceDisplay:U,AVATAR_SIZE:A}),isStrictMode:!0}),this)}}var E=Object.freeze({__proto__:null,default:R})
const L=Object.freeze({type:"plugin",name:"discourse-presence"})
var P={name:"presence-admin-plugin-configuration-nav",initialize(e){const t=e.lookup("service:current-user")
t?.admin&&function(...e){const t="string"==typeof e[0]?2:1
e[t]={...e[t],[f]:L},k(...e)}(e=>{e.setAdminPluginIcon("discourse-presence","eye")})}},N=Object.freeze({__proto__:null,default:P})
class O extends n{static{dt7948.g(this.prototype,"currentUser",[r])}#n=void dt7948.i(this,"currentUser")
static{dt7948.g(this.prototype,"presence",[r])}#t=void dt7948.i(this,"presence")
notifyState(e,t=!0,s=1e4){t?this.currentUser.user_option.hide_presence||this._name!==e&&(this.leave(),this._name=e,this._channel=this.presence.getChannel(e),this._channel.enter(),v()||(this._autoLeaveTimer=b(this,this.leave,s))):this.leave()}leave(){this._autoLeaveTimer&&(C(this._autoLeaveTimer),this._autoLeaveTimer=null),this._channel?.leave(),this._channel=null,this._name=null}}const x={"discourse/components/composer-presence-display":S,"discourse/components/topic-presence-display":B,"discourse/connectors/before-composer-controls/presence":z,"discourse/connectors/topic-footer-presence/presence":E,"discourse/initializers/presence-admin-plugin-configuration-nav":N,"discourse/services/composer-presence-manager":Object.freeze({__proto__:null,default:O})}
export{x as compatModules,x as default}

//# sourceMappingURL=../../map/plugins/discourse-presence_main.DQNMe9-2e55off8.digested.js.map
