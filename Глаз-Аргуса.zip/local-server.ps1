param([string]$StartPath = '/')
$ErrorActionPreference = 'Stop'
$root = [System.IO.Path]::GetFullPath($PSScriptRoot)
$routes = @{}
$routeFile = Join-Path $root 'local-routes.json'
if (Test-Path -LiteralPath $routeFile) {
  $parsed = Get-Content -LiteralPath $routeFile -Raw -Encoding UTF8 | ConvertFrom-Json
  foreach ($prop in $parsed.PSObject.Properties) { $routes[$prop.Name] = [string]$prop.Value }
}
$mime = @{
  '.html'='text/html; charset=utf-8'; '.css'='text/css; charset=utf-8';
  '.js'='application/javascript; charset=utf-8'; '.mjs'='application/javascript; charset=utf-8';
  '.json'='application/json; charset=utf-8'; '.webmanifest'='application/manifest+json';
  '.svg'='image/svg+xml'; '.png'='image/png'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg';
  '.gif'='image/gif'; '.webp'='image/webp'; '.avif'='image/avif'; '.ico'='image/x-icon';
  '.woff'='font/woff'; '.woff2'='font/woff2'; '.ttf'='font/ttf'; '.otf'='font/otf';
  '.wasm'='application/wasm'; '.mp4'='video/mp4'; '.webm'='video/webm'; '.mp3'='audio/mpeg';
  '.txt'='text/plain; charset=utf-8'; '.xml'='application/xml'
}
$listener = $null
for ($attempt = 0; $attempt -lt 20; $attempt++) {
  $probe = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 0)
  $probe.Start()
  $port = ([System.Net.IPEndPoint]$probe.LocalEndpoint).Port
  $probe.Stop()
  $candidate = [System.Net.HttpListener]::new()
  $candidate.Prefixes.Add("http://127.0.0.1:$port/")
  try { $candidate.Start(); $listener = $candidate; break } catch { $candidate.Close() }
}
if (-not $listener) { throw 'Could not start localhost server on a free port.' }
$url = "http://127.0.0.1:$port$StartPath"
Write-Host "Site Recorder local server: $url"
Write-Host 'Keep this window open. Close it to stop the server.'
Start-Process $url
try {
  while ($listener.IsListening) {
    $context = $listener.GetContext()
    try {
      $req = $context.Request; $res = $context.Response
      if ($req.HttpMethod -ne 'GET' -and $req.HttpMethod -ne 'HEAD') { $res.StatusCode = 405; $res.Close(); continue }
      $key = $req.Url.PathAndQuery
      if ($req.Url.AbsolutePath -eq '/') { if (Test-Path -LiteralPath (Join-Path $root 'demo-login-enabled.txt')) { $relative = 'login.html' } else { $relative = 'index.html' } }
      elseif ($routes.ContainsKey($key)) { $relative = $routes[$key] }
      else { $relative = [Uri]::UnescapeDataString($req.Url.AbsolutePath.TrimStart('/')) }
      $candidatePath = [System.IO.Path]::GetFullPath((Join-Path $root $relative))
      $prefix = $root.TrimEnd([char[]]'\/') + [System.IO.Path]::DirectorySeparatorChar
      if (-not $candidatePath.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase) -or -not [System.IO.File]::Exists($candidatePath)) {
        $res.StatusCode = 404; $res.Close(); Write-Host "404 $key"; continue
      }
      $ext = [System.IO.Path]::GetExtension($candidatePath).ToLowerInvariant()
      if ($mime.ContainsKey($ext)) { $res.ContentType = $mime[$ext] } else { $res.ContentType = 'application/octet-stream' }
      $res.Headers['Cache-Control'] = 'no-cache'
      $stream = [System.IO.File]::OpenRead($candidatePath)
      try { $res.ContentLength64 = $stream.Length; if ($req.HttpMethod -eq 'GET') { $stream.CopyTo($res.OutputStream) } }
      finally { $stream.Dispose(); $res.Close() }
    } catch { Write-Host "Request error: $_"; try { $context.Response.Abort() } catch {} }
  }
} finally { $listener.Stop(); $listener.Close() }
